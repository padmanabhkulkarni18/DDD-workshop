package com.aardling.dddinlanguage.application;

public record DroppedFractionRequest(double amount_dropped, String fraction_type) {

}
