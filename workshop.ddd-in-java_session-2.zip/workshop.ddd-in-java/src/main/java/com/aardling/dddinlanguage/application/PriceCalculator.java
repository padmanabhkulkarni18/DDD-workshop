package com.aardling.dddinlanguage.application;

import com.aardling.dddinlanguage.domain.DroppedFraction;
import com.aardling.dddinlanguage.domain.FractionType;
import com.aardling.dddinlanguage.domain.Weight;

public class PriceCalculator {
  public PriceCalculationResponse calculate(PriceCalculationRequest request) {
    var droppedFractions = request.dropped_fractions().stream()
        .map(d -> new DroppedFraction(FractionType.fromString(d.fraction_type()), new Weight(d.amount_dropped())));
    var totalPrice = DroppedFraction.sum(droppedFractions);
    return new PriceCalculationResponse(totalPrice.amount(), totalPrice.currency().toString(), request.visit_id(),
        request.person_id());
  }
}