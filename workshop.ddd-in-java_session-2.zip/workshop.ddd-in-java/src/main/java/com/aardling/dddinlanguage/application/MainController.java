package com.aardling.dddinlanguage.application;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.aardling.dddinlanguage.internal.InMemoryExternalVisitorService;

@RestController
class MainController {
    private static final Logger LOGGER = LoggerFactory.getLogger(MainController.class);
    private Context context;

    @GetMapping("/")
    public ResponseEntity<StatusResponse> home() {
        return ResponseEntity.ok(new StatusResponse("OK"));
    }

    @PostMapping("/startScenario")
    public ResponseEntity<StatusResponse> internalInit() {
        LOGGER.debug("init: start");

        internalInitializeContext();

        LOGGER.debug("init: done");
        return ResponseEntity.ok(new StatusResponse("OK"));
    }

    @PostMapping("/calculatePrice")
    public ResponseEntity<PriceCalculationResponse> calculatePrice(@RequestBody PriceCalculationRequest request) {
        LOGGER.info("request: {}", request);
        var response = new PriceCalculator().calculate(request);

        LOGGER.info("response: {}", response);
        return ResponseEntity.ok(response);
    }

    private record StatusResponse(String status) {

    }

    private void internalInitializeContext() {
        this.context = Context.initialize(new InMemoryExternalVisitorService());
    }
}
