package com.aardling.dddinlanguage.internal;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.Arrays;
import java.util.Optional;

import com.aardling.dddinlanguage.domain.ExternalVisitor;
import com.aardling.dddinlanguage.domain.IExternalVisitorService;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class InMemoryExternalVisitorService implements IExternalVisitorService {
    public InMemoryExternalVisitorService() {
    }

    @Override
    public Optional<ExternalVisitor> getVisitorById(String id) {
        try {
            var visitors = getVisitors();
            return Arrays.stream(visitors).filter(vistor -> vistor.id().equals(id)).findFirst();

        } catch (Exception e) {
            e.printStackTrace();
            return Optional.empty();
        }
    }

    private ExternalVisitor[] getVisitors() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
                false);
        String response = getVisitorsViaApi();
        ExternalVisitor[] vistitors = objectMapper.readValue(response, ExternalVisitor[].class);

        return vistitors;
    }

     String getVisitorsViaApi() throws Exception {
        String authToken = System.getenv("DDD_AUTH_TOKEN");
        String workshopId = System.getenv("WORKSHOP_ID");
        String workshopUrl = System.getenv("WORKSHOP_SERVER_URL");
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI(workshopUrl + "/api/users"))
                .headers("content-type", "application/json", "x-auth-token", authToken, "x-workshop-id",
                        workshopId)
                .timeout(Duration.ofSeconds(10))
                .GET()
                .build();

        HttpResponse<String> response = client.send(request, BodyHandlers.ofString());

        return response.body();
    }
}
