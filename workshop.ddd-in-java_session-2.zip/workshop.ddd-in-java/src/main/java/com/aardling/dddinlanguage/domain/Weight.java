package com.aardling.dddinlanguage.domain;

import java.util.Objects;

public record Weight(double amount) {
    public Weight {
        Objects.requireNonNull(amount);
        if (amount < 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }
    }
}
