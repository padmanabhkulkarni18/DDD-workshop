package com.aardling.dddinlanguage.domain;

public record ExternalVisitor(String type, String id, String address, String city) {

}
