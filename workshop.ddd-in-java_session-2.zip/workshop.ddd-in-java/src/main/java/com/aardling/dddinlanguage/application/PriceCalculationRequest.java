package com.aardling.dddinlanguage.application;

import java.util.List;

public record PriceCalculationRequest(String date, List<DroppedFractionRequest> dropped_fractions, String person_id, String visit_id) {

}