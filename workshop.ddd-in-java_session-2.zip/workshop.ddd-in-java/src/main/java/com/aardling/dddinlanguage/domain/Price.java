package com.aardling.dddinlanguage.domain;

import java.util.Objects;

public record Price(double amount, Currency currency) {
    public Price {
        Objects.requireNonNull(amount);
        Objects.requireNonNull(currency);
        if (amount < 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }
    }

    public Price times(double factor) {
        return new Price(factor * amount, currency);
    }

    public Price add(Price other) {
        return new Price(amount + other.amount, currency);
    }

    public static Price sum(Price p1, Price p2) {
        return p1.add(p2);
    }
}
