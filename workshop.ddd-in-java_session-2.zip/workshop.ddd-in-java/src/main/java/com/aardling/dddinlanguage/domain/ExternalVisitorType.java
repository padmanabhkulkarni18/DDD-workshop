package com.aardling.dddinlanguage.domain;

public enum ExternalVisitorType {
    PRIVATE,
    BUSINESS
}
