package com.aardling.dddinlanguage.domain;

import java.util.Optional;

public interface IExternalVisitorService {
    Optional<ExternalVisitor> getVisitorById(String id);
}