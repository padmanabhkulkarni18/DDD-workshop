package com.aardling.dddinlanguage.domain;

public record FractionType(AllowedFractionType allowedFractionType) {

    public enum AllowedFractionType {
        CONSTRUCTION,
        GREEN;
    }

    public Price price() {
        switch (allowedFractionType) {
            case CONSTRUCTION:
                return new Price(0.15, Currency.EUR);
            case GREEN:
                return new Price(0.1, Currency.EUR);
        }
        return new Price(0, Currency.EUR);
    }

    public static FractionType fromString(String type) {
        switch (type) {
            case "Construction waste":
                return new FractionType(AllowedFractionType.CONSTRUCTION);
            case "Green waste":
                return new FractionType(AllowedFractionType.GREEN);
        }
        throw new IllegalArgumentException(String.format("Invalid fraction type: %s", type));
    }
}