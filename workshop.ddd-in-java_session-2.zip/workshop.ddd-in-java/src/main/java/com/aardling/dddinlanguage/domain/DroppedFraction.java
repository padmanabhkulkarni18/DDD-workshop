package com.aardling.dddinlanguage.domain;

import java.util.stream.Stream;

public record DroppedFraction(FractionType fractionType, Weight weight) {

    public Price calculatePrice() {
        return fractionType.price().times(weight.amount());
    }

    public static Price sum(Stream<DroppedFraction> droppedFractions) {
        return droppedFractions.reduce(new Price(0, Currency.EUR),
                (price, droppedFraction) -> price.add(droppedFraction.calculatePrice()), Price::sum);
    }
}
