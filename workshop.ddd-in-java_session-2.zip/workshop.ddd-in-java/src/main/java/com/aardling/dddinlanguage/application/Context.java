package com.aardling.dddinlanguage.application;

import com.aardling.dddinlanguage.domain.IExternalVisitorService;

public class Context {
    public IExternalVisitorService externalVisitorService;

    private Context(IExternalVisitorService externalVisitorService) {
        this.externalVisitorService = externalVisitorService;
    }

    public static Context initialize(IExternalVisitorService externalVisitorService) {
        return new Context(externalVisitorService);
    }
}