package com.aardling.dddinlanguage.domain;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

public class FractionTypeTests {
    @Test
    void correctType() {
        assertDoesNotThrow(() -> FractionType.fromString("Construction waste"));
    }

    @Test
    void incorrectType() {
        assertThrows(IllegalArgumentException.class, () -> FractionType.fromString("Incorrect"));
    }
}
