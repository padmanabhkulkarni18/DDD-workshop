package com.aardling.dddinlanguage.domain;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.params.provider.Arguments.arguments;

import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import com.aardling.dddinlanguage.domain.FractionType.AllowedFractionType;

public class DroppedFractionTests {
    @ParameterizedTest
    @MethodSource("sumProvider")
    void sum(Stream<DroppedFraction> input, Price expected) {
        assertEquals(DroppedFraction.sum(input), expected);
    }

    static Stream<Arguments> sumProvider() {
        return Stream.of(
                arguments(Stream
                        .of(new DroppedFraction(new FractionType(AllowedFractionType.CONSTRUCTION), new Weight(10))),
                        new Price(10 * 0.15, Currency.EUR)),
                arguments(Stream
                        .of(new DroppedFraction(new FractionType(AllowedFractionType.GREEN), new Weight(10))),
                        new Price(10 * 0.1, Currency.EUR)),
                arguments(Stream
                        .of(new DroppedFraction(new FractionType(AllowedFractionType.CONSTRUCTION), new Weight(10)),
                                new DroppedFraction(new FractionType(AllowedFractionType.GREEN), new Weight(20))),
                        new Price(10 * 0.15 + 20 * 0.1, Currency.EUR))

        );

    }
}
