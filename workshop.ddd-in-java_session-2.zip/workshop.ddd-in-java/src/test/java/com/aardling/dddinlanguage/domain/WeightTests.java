package com.aardling.dddinlanguage.domain;

import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

public class WeightTests {
    @Test
    void weightCannotBeNegative() {
        assertThrows(IllegalArgumentException.class, () -> new Weight(-1));
    }
}
